 class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite um código DDD:");
            int ddd = Convert.ToInt32(Console.ReadLine());

            string cidade;

            switch (ddd)
            {
                case 61:
                    cidade = "Brasília";
                    break;
                case 71:
                    cidade = "Salvador";
                    break;
                case 11:
                    cidade = "São Paulo";
                    break;
                case 21:
                    cidade = "Rio de Janeiro";
                    break;
                case 32:
                    cidade = "Juiz de Fora";
                    break;
                default:
                    cidade = "DDD não cadastrado";
                    break;
            }

            Console.WriteLine(cidade);

            Console.WriteLine("Pressione qualquer tecla para sair.");
            Console.ReadKey();
        }
    }
}